﻿/*************************************************************************************
*	Base de Datos: Daltum Test
*	Autor: Emmanuel Hernández López
*	Fecha: 29 Dic 2022
**************************************************************************************/
--Base de Datos
--CREATE DATABASE DaltumTest_EHL_NETCORE;
--GO
--USE DaltumTest_EHL_NETCORE;
--GO
--Diseño de Tablas
CREATE TABLE C_EstadoCivil(
	IdEstadoCivil INT PRIMARY KEY,
	Descripcion NVARCHAR(50),
	Habilitado BIT
)
--Precarga de datos: EstadoCivil
INSERT INTO C_EstadoCivil SELECT a,b,c FROM (VALUES
	(1,'Soltero(a)',1),
	(2,'Casado(a)',1),
	(3,'Divorciado(a)',1),
	(4,'Viudo(a)',1)
)T(a,b,c);

CREATE TABLE C_Puestos(
	IdPuesto INT PRIMARY KEY,
	Descripcion NVARCHAR(50),
	Habilitado BIT
)
--Precarga de datos: Puestos
INSERT INTO C_Puestos SELECT a,b,c FROM (VALUES
	(1,'Director General',1),
	(2,'Director de Publicidad y Marketing',1),
	(3,'Director de Sistemas',1),
	(4,'Director de Recursos Humanos',1),
	(5,'Director de Finanzas',1),
	(76,'Director de Ventas',1)
)T(a,b,c);


CREATE TABLE Empleados(
	IdEmpleado INT IDENTITY PRIMARY KEY NOT NULL,
	CodigoEmpleado NVARCHAR(10) UNIQUE NOT NULL,
	Nombre NVARCHAR(50) NOT NULL,
	ApellidoPaterno NVARCHAR(50) NOT NULL,
	ApellidoMaterno NVARCHAR(50) NOT NULL,
	Edad INT NOT NULL,
	FechaNacimiento DATE NOT NULL,
	Genero NVARCHAR(1) NOT NULL, --H o M
	EstadoCivil INT REFERENCES C_EstadoCivil(IdEstadoCivil) NOT NULL, 
	Rfc NVARCHAR(15) NOT NULL,
	Direccion NVARCHAR(500) NOT NULL,
	Email NVARCHAR(50) NOT NULL, 
	Telefono  NVARCHAR(15) NOT NULL, 
	puesto INT REFERENCES C_Puestos(IdPuesto) NOT NULL, 
	FechaAlta DATE NOT NULL,
	FechaBaja DATE,
	Habilitado BIT NOT NULL
)

INSERT INTO Empleados VALUES('0001','Emmanuel','Hernandez','Lopez',37,'1984-12-17',0,1,'HELE841217DF5','Los Amores Tellez, Zempoala Hidalgo, CP 48350','herlem.kx@gmail.com','5585681329',3,'2022-12-29',NULL,1);