﻿using DaltumTest.API.Catalogs;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace BPT.API.Customer.V1.Validations.Generic
{
    public class Requerid : ValidationAttribute
    {       
        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {
           
            var _value = value?.ToString();


            if (value==null || (value.GetType()==typeof(Guid) &&(Guid)value==Guid.Empty) || String.IsNullOrEmpty(_value))
            {
                return new ValidationResult("Dato requerido.");
            }else
            return ValidationResult.Success;
        }
    }
    public class Email : ValidationAttribute
    {
        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {

            var _value = value?.ToString();


            if (!String.IsNullOrEmpty(_value) && !(new Regex(RegExp.Email[1]).IsMatch(_value)))
            {
                return new ValidationResult("Formato inválido.");
            }
            else
                return ValidationResult.Success;
        }
    }
    public class PhoneNumber : ValidationAttribute
    {
        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {

            var _value = value?.ToString();


            if (!String.IsNullOrEmpty(_value) && !(new Regex(RegExp.PhoneNumber[1]).IsMatch(_value)))
            {
                return new ValidationResult("Formato inválido.");
            }
            else
                return ValidationResult.Success;
        }
    }
}
