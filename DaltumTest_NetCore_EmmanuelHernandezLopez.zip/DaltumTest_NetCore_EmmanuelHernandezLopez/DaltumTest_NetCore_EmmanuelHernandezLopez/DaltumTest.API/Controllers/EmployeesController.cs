using DaltumTest.API.Interfaces;
using DaltumTest.API.Models;
using Microsoft.AspNetCore.Mvc;

namespace DaltumTest.API.Controllers
{
    [ApiController]
    [Route("api/[controller]/")]
    public class EmployeesController : ControllerBase
    {

        private readonly ILogger<EmployeesController> _logger;
        private readonly IEmployeeServices EmployeeService;

        public EmployeesController(ILogger<EmployeesController> logger, IEmployeeServices _EmployeeService)
        {
            _logger = logger;
            EmployeeService = _EmployeeService;
        }

        [HttpGet, Route("Search")]
        public async Task<ActionResult<object>> SearchEmployees(string? nombre, string? rfc, bool? estatus)
        {
            try
            {
                return StatusCode(200, new { Message = "OK", Code = 5, Employees = await EmployeeService.Search(nombre, rfc, estatus) });
            }
            catch (Exception ex) {
                return StatusCode(400,new {Message=ex.Message,Code=0 });
            }
        }

        [HttpPut,Route("Add")]
        public async Task<ActionResult<object>> AddEmployee(Employee employee)
        {
            try
            {
                await EmployeeService.Add(employee);
                return StatusCode(200, new { Message = "Empleado dado de alta correctamente", Code = 1 });
            }
            catch (Exception ex)
            {
                return StatusCode(400, new { Message = ex.Message, Code = 0 });
            }
        }
        [HttpPost, Route("Update")]
        public async Task<ActionResult<object>> EditEmployee(Employee employee)
        {
            try
            {
                return StatusCode(200, new { Code = 1, Message = "Alta de Empleado con �xito." });
            }
            catch (Exception ex)
            {
                return StatusCode(400, new { Message = ex.Message, Code = 2 });
            }
        }
        [HttpDelete, Route("Delete")]
        public async Task<ActionResult<object>> DeleteEmployee(int IdEmpleado)
        {
            try
            {
                await EmployeeService.Delete(IdEmpleado);
                return new { Code = 1, Message = "Empleado dado de Baja con �xito." };
            }
            catch (Exception ex)
            {
                return StatusCode(400, new { Message = ex.Message, Code = 0 });
            }
        }
    }
}