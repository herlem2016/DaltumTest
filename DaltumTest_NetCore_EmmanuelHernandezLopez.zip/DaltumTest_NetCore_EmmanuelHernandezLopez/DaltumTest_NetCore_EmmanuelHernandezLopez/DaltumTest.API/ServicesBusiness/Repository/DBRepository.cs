﻿using Abstractions.Data;
using DaltumTest.API.Interfaces;
using DaltumTest.API.Models;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace DaltumTest.API.Repository
{
    public class DBRepository : IDBRepository
    {
        private ILogger<DBRepository> Logger { get; }
        private readonly DBContext DBContext;

        public DBRepository(
            ILogger<DBRepository> logger,
            DBContext _DBContext)
        {
            Logger = logger;
            DBContext = _DBContext;
        }

        public async Task<object> GetUserProcessor(string user)
        {
            return DBContext.Employees.FirstOrDefault(a => 1==1);
        }

        public async Task<List<Employee>> SearchEmployees(string? nombre, string? rfc, bool? estatus)
        {

            List<Employee> Employees = DBContext.Employees.Where(o=>
                (nombre==null ||nombre.Trim().Length==0 || (o.Nombre + " " + o.ApellidoPaterno + " " + o.ApellidoMaterno).Contains(nombre??""))&&
                    (rfc==null || rfc.Trim().Length==0 || o.Rfc.Contains(rfc??""))&&
                    (o.Habilitado==estatus)
            ).ToList();
            return Employees;
        }

        public async Task DeleteEmployee(int idEmpleado)
        {
            var EmployeeDelete= DBContext.Employees.Where(o => o.IdEmpleado==idEmpleado).FirstOrDefault();
            if (EmployeeDelete != null){
                EmployeeDelete.Habilitado = false;
                DBContext.SaveChanges();
            }
        }

        public async Task AddEmployee(Employee employee)
        {
            employee.CodigoEmpleado = Guid.NewGuid().ToString().Substring(0,8);
            if (employee.FechaBaja.Length == 0) employee.FechaBaja = null;
            DBContext.Employees.Add(employee);
            DBContext.SaveChanges();
        }
    }
}
