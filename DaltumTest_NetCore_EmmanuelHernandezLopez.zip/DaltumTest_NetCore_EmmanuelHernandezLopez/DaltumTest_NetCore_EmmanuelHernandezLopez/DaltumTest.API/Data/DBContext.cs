﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using DaltumTest.API.Models;

namespace Abstractions.Data
{
    public partial class DBContext : DbContext
    {
        public DBContext()
        {
        }

        public DBContext(DbContextOptions<DBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Employee> Employees { get; set; } = null!;
        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<Account>(entity =>
            //{
            //    entity.Property(e => e.AccountId).ValueGeneratedNever();

            //    entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

            //    entity.HasOne(d => d.AuthorizerBalance)
            //        .WithMany(p => p.Accounts)
            //        .HasForeignKey(d => d.AuthorizerBalanceId)
            //        .OnDelete(DeleteBehavior.ClientSetNull)
            //        .HasConstraintName("FK_Accounts_AuthorizerBalance");
            //});

           

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
