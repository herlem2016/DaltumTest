using Abstractions.Data;
using DaltumTest.API.Interfaces;
using DaltumTest.API.Repository;
using DaltumTest.API.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
IConfiguration Configuration = builder.Configuration;

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
//Cadenas de conexion a Base de Datos
builder.Services.AddDbContext<DBContext>(options => options.UseSqlServer(Configuration.GetConnectionString("DBContext")));
//Configuraciones
//builder.Services.Configure<EndPointNotificationsAPI>(Configuration.GetSection("EndPointNotificationsAPI"));
//Servicios
builder.Services.AddScoped<IEmployeeServices, EmployeeServices>()
        .AddScoped<IDBRepository, DBRepository>();

builder.Services.AddSwaggerGen();
builder.Services.AddCors(options =>
{
    options.AddPolicy(name: "Cors",
                      builder =>
                      {
                          builder.WithOrigins("http://localhost:5044")
                          .AllowAnyMethod()
                          .AllowAnyHeader();
                      });
});
var app = builder.Build();



app.UseCors("Cors");

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}


app.UseAuthorization();

app.MapControllers();

app.Run();
