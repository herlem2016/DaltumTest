﻿// Codigo Demostración: Test técnico Daltum Systems
// Autor: Emmanuel Hernández López
// Fecha: 28/12/2022

function ShowEditEmployee() {    
    $('#optionsModal').modal('hide');
    $("#fNombre").val(TEmployee.selected.item.nombre),
    $("#fApellidoPaterno").val(TEmployee.selected.item.apellidoPaterno),
    $("#fApellidoMaterno").val(TEmployee.selected.item.apellidoMaterno),
    $("#fEdad").val(TEmployee.selected.item.edad),
    $("#fFechaNacimiento").val(TEmployee.selected.item.fechaNacimiento),
    $("#fGenero").val(TEmployee.selected.item.genero),
    $("#fEstadoCivil").val(TEmployee.selected.item.estadoCivil),
    $("#fRfc").val(TEmployee.selected.item.rfc),
    $("#fDomicilio").val(TEmployee.selected.item.direccion),
    $("#fEmail").val(TEmployee.selected.item.email),
    $("#fTelefono").val(TEmployee.selected.item.telefono),
    $("#fPuesto").val(TEmployee.selected.item.puesto),
    $("#fFechaAlta").val(TEmployee.selected.item.fechaAlta),
    $("#fFechaBaja").val(TEmployee.selected.item.fechaBaja)
}

function DeleteHandlerCallback(result) {
    $("#deleteModal").modal('hide');
    if (result.code == 1) {
        alert(result.message);
        TEmployee.Search(function () { TEstatusApp.Change("DEmployees"); });
    } else {
        alert("No se logró eliminar el Empleado.");
    }
}

function ShowEmployeeDown(obj) {
    TEmployee.selected = obj.parentNode.parentNode;
    $("#e-nombre").html("Nombre: " +TEmployee.selected.item.nombre + " " + TEmployee.selected.item.apellidoPaterno + " " + TEmployee.selected.item.apellidoMaterno);
    $("#e-domicilio").html("Domicilio: "+TEmployee.selected.item.direccion);
    $("#e-puesto").html("Puesto: " +TEmployee.selected.item.puesto);
    
}
 
class Employee {
    constructor() {
        this.URL_API = "http://localhost:5146/api/employees/";
        this.selected = null;
    }
}

Employee.prototype.Add = function (formEmployee) {
    var employee=
    {
      idEmpleado: 0,
      codigoEmpleado: "0",
      nombre: $("#fNombre").val(),
      apellidoPaterno: $("#fApellidoPaterno").val(),
      apellidoMaterno: $("#fApellidoMaterno").val(),
      edad: $("#fEdad").val(),
      fechaNacimiento: $("#fFechaNacimiento").val(),
      genero: $("#fGenero").val(),
      estadoCivil: $("#fEstadoCivil").val(),
      rfc: $("#fRfc").val(),
      direccion: $("#fDomicilio").val(),
      email: $("#fEmail").val(),
      telefono: $("#fTelefono").val(),
      puesto: $("#fPuesto").val(),
      fechaAlta: $("#fFechaAlta").val(),
      fechaBaja: $("#fFechaBaja").val(),
      habilitado: true
    }
    $.ajax({
        url: this.URL_API + 'Add',
        type: 'PUT',
        data: JSON.stringify(employee),
        contentType:'application/json',
        success: function (result) {
            console.log(result);
            TEmployee.Search(function () { TEstatusApp.Change("DEmployees"); });
            $("#formEmployee").modal('hide');
            alert(result.message);
        },
        error: function (result) {
            alert("Todos los campos son obligatorios,ecepto fecha de baja.");   
        }
    });
}

Employee.prototype.Delete = function (callback) {
    let idEmpleado = this.selected.item.idEmpleado;
    console.log(idEmpleado);
    $.ajax({
        url: this.URL_API + 'delete?IdEmpleado=' + idEmpleado,
        type: 'DELETE',
        success: function (result) {
            console.log(result);
            if (callback) callback(result);
        },
        error: function (result) {

        }
    });
}

Employee.prototype.Update= function(formEmployee) {
    $.ajax({
        url: this.URL_API + 'update',
        type: 'POST',
        success: function (result) {
            console.log(result);
            if (result.code == 1) {

            } else {

            }
        },
        error: function (result) {

        }
    });
}

Employee.prototype.Search= function(callback){
    let inNombre = $("#inNombre").val();
    let inRfc = $("#inRfc").val();
    let inEstatus = $("select#inEstatus").val();
    $.ajax({
        url: this.URL_API + 'search',
        type: 'GET',
        data: {rfc:inRfc,nombre:inNombre,estatus:inEstatus },
        success: function (result) {
            console.log("Result Search");
            if (result.employees) {
                TEstatusApp.Data.DEmployees.dataSource = result.employees;
                console.log(result.employees);
                if (callback) callback();
            }
        },
        error: function (result) {
            console.log("Error search Employees");
        }
    });
}

class EstatusApp { 
    constructor() {
        this.Data = {};
    }

    Change(var_estatus) {
        let triggers = this.Data[var_estatus].triggers;
        for (var k = 0; k < triggers.length; k++) {
            console.log("Ejecución Triggers.");
            triggers[k].fn(this.Data[var_estatus].dataSource, triggers[k].node, triggers[k].nodeParent, this.Data[var_estatus].localName, this.Data[var_estatus].it );
        }
    }

    Initialize() {
        let controls = ["for"];
        for (var n = 0; n < controls.length; n++) {
            switch (controls[n]) {
                case "for": {
                    let nodes_for = $("[control=for]");
                    console.log("for's:" + nodes_for.length);
                    for (let j = 0; j < nodes_for.length; j++) {
                        let estatus_data = nodes_for[j].getAttribute("source");
                        let it = nodes_for[j].getAttribute("it");
                        if (!this.Data[estatus_data]) this.Data[estatus_data] = { localName: estatus_data, triggers: [], dataSource: [], it: it };                        
                        this.Data[estatus_data].triggers.push({ name: "forIt", fn: forIt, node: nodes_for[j].innerHTML, nodeParent: nodes_for[j] });
                        nodes_for[j].innerHTML = "";
                        nodes_for[j].style.display = "";
                    }
                } break;
            }
        }
    }

}

function forIt(dataFor, nodeHtml, nodeParent, dataName, iterator) {
    $(nodeParent).html("");
    console.log("let " + dataName + "=dataFor;");
    eval("var " + dataName + "=dataFor;");
    eval("let " + iterator + "= 0;");
    console.log("dataFor-length:" + DEmployees.length);
    for (var n = 0; n < dataFor.length; n++) {
        eval(iterator + "= " + n + ";");
        console.log("Lectura de iterador.");
        let sNode = nodeHtml;
        let sNodeCopy = sNode;
        let execsIn = sNode.match(RegExp('\{(.*?)\}', 'g'));
        execsIn = (execsIn ? execsIn : []);
        console.log("execsIn.length: " + execsIn.length);
        for (var ii = 0; ii < execsIn.length; ii++) {
            try {
                console.log("Match[" + ii + "]: " + execsIn[ii]);
                eval("valReplace=" + execsIn[ii].substring(1, execsIn[ii].length - 1));
                sNodeCopy = sNodeCopy.replace(execsIn[ii], (valReplace ? valReplace : ""));
                sNodeCopy = sNodeCopy.replace(RegExp('if="checked"', 'g'),"checked=''");
                console.log(eval(execsIn[ii]));
            } catch (e) { console.log(e.message); }
        }
        var rowInsert = $(nodeParent).append(sNodeCopy);
        var trs = rowInsert.find("tr");
        trs[trs.length-1].item = dataFor[n];
    }
}

var TEmployee;
var TEstatusApp;
$(function () { 
    TEstatusApp = new EstatusApp();
    TEstatusApp.Initialize();
    TEmployee = new Employee();
    TEmployee.Search(function () { TEstatusApp.Change("DEmployees"); });
    console.log("Class Employee creado."); 
});
