﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DaltumTest.API.Models
{
    [Table("Empleados", Schema = "softrone_daltum")]
    public class Employee
    {
        [Key][Required] public int IdEmpleado { get; set; }
        [Required][StringLength(10)] public string CodigoEmpleado { get; set; }
        [Required][StringLength(50)] public string Nombre { get; set; }
        [Required][StringLength(50)] public string ApellidoPaterno { get; set; }
        [Required][StringLength(50)] public string ApellidoMaterno { get; set; }
        [Required] public int Edad { get; set; }
        [Required][Column(TypeName = "date")] public DateTime FechaNacimiento { get; set; }
        [Required][StringLength(1)] public string Genero { get; set; }
        [Required] public int EstadoCivil { get; set; }
        [Required][StringLength(12)] public string Rfc { get; set; }
        [Required][StringLength(50)] public string Direccion { get; set; }
        [Required][StringLength(50)] public string Email { get; set; }
        [Required][StringLength(15)] public string Telefono { get; set; }
        [Required] public int puesto { get; set; }
        [Required][Column(TypeName = "date")] public DateTime FechaAlta { get; set; }
        [Column(TypeName = "date")] public DateTime? FechaBaja { get; set; }
        [Required] public bool Habilitado { get; set; }
    }
}
