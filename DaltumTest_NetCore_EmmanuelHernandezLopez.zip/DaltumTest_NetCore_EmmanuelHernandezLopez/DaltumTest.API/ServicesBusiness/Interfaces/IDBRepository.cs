﻿using DaltumTest.API.Models;
using Microsoft.Extensions.Primitives;
using System.Net;

namespace DaltumTest.API.Interfaces
{
    public interface IDBRepository
    {

        Task<object> GetUserProcessor(string user);
        Task<List<Employee>> SearchEmployees(string nombre, string rfc, bool estatus);
        Task DeleteEmployee(int idEmpleado);
    }
}
