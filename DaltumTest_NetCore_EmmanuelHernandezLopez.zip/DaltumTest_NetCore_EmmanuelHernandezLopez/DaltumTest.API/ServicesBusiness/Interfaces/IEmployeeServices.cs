﻿using DaltumTest.API.Models;

namespace DaltumTest.API.Interfaces
{
    public interface IEmployeeServices
    {
        Task<bool> IsValidUser(string user, string password);
        Task<List<Employee>> Search(string nombre, string rfc, bool estatus);
        Task Delete(int idEmpleado);
    }
}
