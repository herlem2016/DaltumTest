﻿using DaltumTest.API.Interfaces;
using DaltumTest.API.Models;

namespace DaltumTest.API.Services
{
    public class EmployeeServices : IEmployeeServices
    {
        private readonly IDBRepository DBRespository;

        public EmployeeServices(IDBRepository _DBRespository)
        {
            DBRespository = _DBRespository;
        }

        public async Task Delete(int idEmpleado)
        {
            await DBRespository.DeleteEmployee(idEmpleado);
        }

        public async Task<bool> IsValidUser(string user, string password)
        {
            

            return false;

        }

        public async Task<List<Employee>> Search(string nombre, string rfc, bool estatus)
        {
            return await DBRespository.SearchEmployees(nombre,rfc,estatus);
        }
    }
}
